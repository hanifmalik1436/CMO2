# CMO² Master Command Platform

Multi-tenant SaaS marketing command center. This repository is being built from the
planning docs (`01`–`05` + `CMO2_SPRINGBOOT_REACT_SAAS_PLAN.md`) following the
strictly-sequential phase plan in `CLAUDE.md`.

## What is implemented now (Phase 0 + Phase 1 core + Phase 2)

This is the **foundation plus the Strange Loop engine** — the operating system the rest of
the product plugs into:

- ✅ **Backend skeleton** — Spring Boot 3.3 (Java 17), Maven, OpenAPI/Swagger, Actuator health.
- ✅ **Auth** — register, login, JWT access + rotating refresh tokens, BCrypt(12), account lockout.
- ✅ **Multi-tenancy** — `tenant_id` discriminator on every tenant-owned table, JWT `tenant_id`
  claim → `TenantContext` (ThreadLocal) → Hibernate `@Filter` auto-scoping + entity listener
  auto-stamping. Clients can never supply `tenant_id`. Enforced on the WebSocket channel too.
- ✅ **RBAC** — `OWNER > ADMIN > STRATEGIST > ANALYST > VIEWER`, enforced at the service layer via `@PreAuthorize`.
- ✅ **Companies** — CRUD scoped to the tenant (the Multi-Company module's data backbone).
- ✅ **Strange Loop OS (Phase 2)** — the live 5-stage cycle (Innovation → Learning →
  Documentation → Reporting → Optimization). Async orchestrator, each stage transition
  persisted to `loop_stage_runs` so a **crashed cycle resumes** (not restarts), real-time
  progress over **STOMP/SockJS** (`/topic/tenant.{id}.loop`), iteration history with
  insights/gaps JSON, and auto-rescheduling of the next cycle. *(Stage bodies are honest
  stubs — they produce real structured output but say "no KPI data yet"; Phases 3–5 fill them in.)*
- ✅ **Flyway V1 + V2** — identity/tenancy/companies, then `loop_iterations, loop_stage_runs, loop_triggers`.
- ✅ **Frontend shell** — React 19 + Vite + TypeScript + Tailwind, AppShell (sidebar/topbar),
  login/register, route guards, dashboard, companies view, **live Strange Loop visualization**,
  Axios w/ silent refresh, TanStack Query, Zustand, STOMP client.
- ✅ **Docker Compose** — backend, frontend, MySQL 8, Redis 7, Mailhog.

## Not yet implemented (later phases — see `03_HIGH_LEVEL_PLAN.md`)

GoHighLevel + connectors (P3/P8), AI asset generation (P4), AI strategists (P5),
analytics/alerts/auto-docs (P6), Stripe billing (P7). The architecture, package layout, and
security model here are built so those modules drop in without rework — the Strange Loop
stages already have the seams where AI/KPI/documentation logic attaches.

## Prerequisites

### Software

| Software | Version | Status | Needed for |
|---|---|---|---|
| **Docker Desktop** / Docker Engine + Compose v2 | latest | **Mandatory for Path A** · Optional for Path B | Path A runs the whole stack; Path B uses it only to spin up MySQL/Redis/Mailhog |
| **JDK 17** (Temurin/Adoptium) | 17 (LTS) | **Mandatory for Path B** (backend) | Compiling/running the Spring Boot backend natively |
| **Maven** | 3.9+ | **Mandatory for Path B** (backend) | Building/running/testing the backend (no `./mvnw` wrapper committed yet) |
| **Node.js + npm** | Node 20+ | **Mandatory for Path B** (frontend) | Building/running the React frontend natively |
| **Git** | latest | Optional | Cloning the repo / version control |
| **A modern browser** | latest | Mandatory | Using the app at `localhost:5173` |

> With **Path A (Docker)** you need *only* Docker — JDK, Maven, and Node all run inside containers.

### External accounts / API keys

The current **Phase 0 + Phase 1 foundation needs no external accounts** — you can sign up,
log in, and manage companies with nothing but the software above. The accounts below are
introduced by later phases (see `03_HIGH_LEVEL_PLAN.md`); list provided so you can plan ahead.

| Account / service | Status (today) | Becomes required in | Used for |
|---|---|---|---|
| *(none)* | — | — | The foundation runs fully offline/local |
| **Anthropic Claude API** | Optional | Phase 4–5 | AI asset generation & strategist agents (frontier reasoning) |
| **OpenAI API** | Optional | Phase 4 | Bulk content + EN→ES translation tier (provider-agnostic `AiService`) |
| **GoHighLevel** | Optional | Phase 3 | First platform connector (reference integration) |
| **Stripe** | Optional | Phase 7 | Subscription billing (hosted Checkout/Portal) |
| **SendGrid / Amazon SES** | Optional | Phase 6 | Production transactional + alert email (Mailhog covers local dev) |
| **Twilio** | Optional | Phase 6 | SMS alerts |
| **Slack (incoming webhook)** | Optional | Phase 6 | Team alert channel |
| **Notion / Confluence / Linear** | Optional | Phase 6 | Strange Loop Stage-3 auto-documentation |
| **Meta / LinkedIn / Google Ads / TikTok / etc.** | Optional | Phase 8 | Connectors #2–#15 |

> When a phase needs one of these, its key is supplied via **environment variables / Docker
> secrets** — never committed to the repo (see *Security notes*).

## Run it locally

You have two paths. **Path A (Docker)** needs nothing but Docker installed. **Path B
(native)** runs the backend and frontend directly on your machine and is best for active
development (fast hot-reload, debugger attach).

### Ports & URLs (both paths)

| Service | URL |
|---|---|
| Frontend (SPA) | http://localhost:5173 |
| Backend API | http://localhost:8080 |
| Swagger UI (API docs) | http://localhost:8080/swagger-ui.html |
| Health probe | http://localhost:8080/actuator/health |
| Mailhog (catches verification emails) | http://localhost:8025 |

---

### Path A — Everything via Docker (simplest)

**Prerequisites:** Docker Desktop (or Docker Engine + Compose v2).

```bash
# from the repo root
docker compose up --build
```

This starts backend, frontend, MySQL 8, Redis 7, and Mailhog. First build takes a few
minutes (Maven + npm download dependencies). When you see the backend log
`Started Cmo2Application`, open http://localhost:5173.

```bash
docker compose down        # stop
docker compose down -v     # stop and wipe the MySQL volume (fresh DB next start)
docker compose logs -f backend   # tail backend logs
```

---

### Path B — Run natively (recommended for development)

**Prerequisites:**
- **JDK 17** (Temurin/Adoptium recommended) — verify with `java -version`
- **Maven 3.9+** — verify with `mvn -v`  *(no `./mvnw` wrapper is committed yet)*
- **Node.js 20+** and npm — verify with `node -v`
- **Docker** *(optional)* — only to run MySQL/Redis/Mailhog; skip if you have your own MySQL

#### 1. Start the infrastructure (MySQL + Redis + Mailhog)

Easiest is to let Compose run just those three:

```bash
docker compose up -d mysql redis mailhog
```

<details>
<summary>No Docker? Use your own MySQL instead</summary>

Create the database and user the backend expects (defaults from `application.yml`):

```sql
CREATE DATABASE cmo2 CHARACTER SET utf8mb4;
CREATE USER 'cmo2'@'%' IDENTIFIED BY 'cmo2pw';
GRANT ALL PRIVILEGES ON cmo2.* TO 'cmo2'@'%';
FLUSH PRIVILEGES;
```

Redis and Mailhog are optional for the foundation (nothing fails without them — mail just
logs a warning). Point at a different DB/host with the env vars in step 2.
</details>

#### 2. Run the backend (terminal 1)

```bash
cd cmo2-backend
mvn spring-boot:run
```

Flyway applies `V1__init.sql` automatically on first start. The API is up when the log
shows `Started Cmo2Application` — check http://localhost:8080/actuator/health (`{"status":"UP"}`).

The backend reads config from `cmo2-backend/src/main/resources/application.yml`, which
already defaults to `localhost` MySQL/Redis. Override any of these via environment variables
if your setup differs:

```bash
# examples — only set what you need to change
export SPRING_DATASOURCE_URL="jdbc:mysql://localhost:3306/cmo2?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"
export SPRING_DATASOURCE_USERNAME=cmo2
export SPRING_DATASOURCE_PASSWORD=cmo2pw
export SPRING_DATA_REDIS_HOST=localhost
# In a shared/staging env, ALWAYS override these dev defaults:
export CMO2_JWT_SECRET="<a long random string, 64+ chars>"
export CMO2_CRYPTO_MASTER_KEY="<base64 of exactly 32 random bytes>"
```
> On Windows PowerShell use `$env:NAME = "value"` instead of `export`.

Run the test suite (uses in-memory H2 — **no MySQL needed**), including the tenant-leak suite:

```bash
mvn test
```

#### 3. Run the frontend (terminal 2)

```bash
cd cmo2-frontend
cp .env.example .env.local      # sets VITE_API_BASE_URL=http://localhost:8080
npm install                     # first time only
npm run dev
```

Vite serves http://localhost:5173 with hot reload and proxies API calls to the backend in
terminal 1. Other useful scripts:

```bash
npm run build     # type-check (tsc) + production build into dist/
npm run lint
```

---

## First steps after start

1. Open http://localhost:5173 and click **Register** — this creates a new **tenant** + an
   **OWNER** user, and signs you in.
2. (Optional) Open http://localhost:8025 (Mailhog) to see the verification email; click its
   link to verify the address.
3. You land on an empty, tenant-isolated dashboard. Add a couple of **Companies**.
4. Open **Strange Loop** in the sidebar, pick a company, and click **▶ Run Cycle** — watch the
   5 stages light up live (driven by WebSocket), then see the iteration in the history list.
5. Register a **second account** in an incognito window — confirm the two tenants cannot see
   each other's companies or loop cycles. (This is also what `mvn test`'s `TenantIsolationTest`
   and `StrangeLoopCycleTest` prove.)

## Troubleshooting

- **`java`/`mvn` not found** → install JDK 17 + Maven 3.9, or use Path A (Docker).
- **Backend fails with `Communications link failure` / `Access denied`** → MySQL isn't up yet
  or credentials differ; ensure `docker compose up -d mysql` is healthy, or fix the
  `SPRING_DATASOURCE_*` vars.
- **`Flyway validate failed` / schema mismatch** → you have an old DB; reset it with
  `docker compose down -v` (Docker) or `DROP DATABASE cmo2; CREATE DATABASE cmo2;`.
- **Frontend can't reach the API / CORS error** → confirm the backend is on `:8080` and
  `VITE_API_BASE_URL` in `.env.local` matches. Allowed origins are set by
  `CMO2_CORS_ALLOWED_ORIGINS` (defaults to `http://localhost:5173`).
- **Port already in use** → stop whatever holds `5173`/`8080`/`3306`, or change the mapped
  ports in `docker-compose.yml`.

## Security notes

- Dev secrets in `docker-compose.yml` are **for local use only**. Provide real values via
  environment / Docker secrets in any shared environment.
- Schema changes go through **Flyway only** (`src/main/resources/db/migration`). Never hand-edit the DB.
