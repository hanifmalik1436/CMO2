import { useQuery } from '@tanstack/react-query'
import { api } from '../../lib/api'
import { GlassCard, PageHeader } from '../../components/ui/GlassCard'
import { useSession } from '../../stores/session'
import type { Company } from '../../lib/types'

// The portfolio KPI strip from the prototype. Values are placeholders until
// Phase 3 wires live platform data into kpi_snapshots.
const KPIS = [
  { label: 'Leads', value: '—', hint: 'Phase 3' },
  { label: 'CPL', value: '—', hint: 'Phase 3' },
  { label: 'ROAS', value: '—', hint: 'Phase 3' },
  { label: 'Conv. rate', value: '—', hint: 'Phase 3' },
  { label: 'Appointments', value: '—', hint: 'Phase 3' },
]

export default function DashboardPage() {
  const user = useSession((s) => s.user)

  const { data: companies, isLoading } = useQuery<Company[]>({
    queryKey: ['companies'],
    queryFn: async () => (await api.get<Company[]>('/api/companies')).data,
  })

  const activeCompanies = companies?.filter((c) => c.status === 'ACTIVE').length ?? 0

  return (
    <div>
      <PageHeader
        title={`Welcome${user?.fullName ? `, ${user.fullName.split(' ')[0]}` : ''}`}
        subtitle="Your unified marketing command center."
      />

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {KPIS.map((k) => (
          <GlassCard key={k.label}>
            <div className="text-xs uppercase tracking-wide text-gray-400">{k.label}</div>
            <div className="mt-2 text-2xl font-semibold text-white">{k.value}</div>
            <div className="mt-1 text-[11px] text-gray-500">live in {k.hint}</div>
          </GlassCard>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <GlassCard className="lg:col-span-2">
          <h2 className="mb-3 text-sm font-semibold text-white">Getting started</h2>
          <ol className="space-y-2 text-sm text-gray-300">
            <li>1. Add a <span className="text-brand-glow">Company</span> (a brand you manage).</li>
            <li>2. Connect a platform — GoHighLevel first <span className="text-gray-500">(Phase 3)</span>.</li>
            <li>3. Generate &amp; deploy an asset <span className="text-gray-500">(Phase 4)</span>.</li>
            <li>4. Run a Strange Loop cycle <span className="text-gray-500">(Phase 2)</span>.</li>
          </ol>
        </GlassCard>

        <GlassCard>
          <h2 className="mb-3 text-sm font-semibold text-white">Portfolio</h2>
          {isLoading ? (
            <p className="text-sm text-gray-400">Loading…</p>
          ) : (
            <div className="space-y-1 text-sm text-gray-300">
              <div className="flex justify-between"><span>Companies</span><span className="text-white">{companies?.length ?? 0}</span></div>
              <div className="flex justify-between"><span>Active</span><span className="text-white">{activeCompanies}</span></div>
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  )
}
