import { createBrowserRouter, Navigate } from 'react-router-dom'
import AppShell from './AppShell'
import RequireAuth from './guards/RequireAuth'
import LoginPage from '../features/auth/LoginPage'
import RegisterPage from '../features/auth/RegisterPage'
import VerifyEmailPage from '../features/auth/VerifyEmailPage'
import DashboardPage from '../features/dashboard/DashboardPage'
import CompaniesPage from '../features/companies/CompaniesPage'
import StrangeLoopPage from '../features/strangeLoop/StrangeLoopPage'
import ModulePlaceholder from '../features/ModulePlaceholder'

export const router = createBrowserRouter([
  { path: '/login', element: <LoginPage /> },
  { path: '/register', element: <RegisterPage /> },
  { path: '/verify-email', element: <VerifyEmailPage /> },
  {
    element: <RequireAuth />,
    children: [
      {
        element: <AppShell />,
        children: [
          { path: '/', element: <Navigate to="/dashboard" replace /> },
          { path: '/dashboard', element: <DashboardPage /> },
          { path: '/companies', element: <CompaniesPage /> },
          { path: '/strange-loop', element: <StrangeLoopPage /> },
          {
            path: '/integrations',
            element: <ModulePlaceholder title="Integrations Hub" phase="Phase 3" blurb="15 platform connectors, starting with GoHighLevel." />,
          },
          {
            path: '/assets',
            element: <ModulePlaceholder title="AI Asset Generator" phase="Phase 4" blurb="Generate → translate (EN→ES) → deploy." />,
          },
          {
            path: '/strategists',
            element: <ModulePlaceholder title="AI Strategist Council" phase="Phase 5" blurb="17 specialist agents with review gates RG-1..RG-4." />,
          },
          {
            path: '/analytics',
            element: <ModulePlaceholder title="Analytics" phase="Phase 6" blurb="KPI dashboards, trends, A/B panels." />,
          },
          {
            path: '/reports',
            element: <ModulePlaceholder title="Reports" phase="Phase 6" blurb="Scheduled leadership-ready PDF reports." />,
          },
          {
            path: '/alerts',
            element: <ModulePlaceholder title="Alerts" phase="Phase 6" blurb="Threshold rules across email, SMS, and Slack." />,
          },
          {
            path: '/settings',
            element: <ModulePlaceholder title="Settings & Admin" phase="Phase 1 / 7" blurb="Team management, RBAC, audit log, data export." />,
          },
          {
            path: '/billing',
            element: <ModulePlaceholder title="Billing" phase="Phase 7" blurb="Stripe plans, checkout, and the customer portal." />,
          },
        ],
      },
    ],
  },
  { path: '*', element: <Navigate to="/dashboard" replace /> },
])
