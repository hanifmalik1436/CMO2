// Shared API types — mirror the backend DTOs (com.cmo2.*.dto).

export type Role = 'OWNER' | 'ADMIN' | 'STRATEGIST' | 'ANALYST' | 'VIEWER'

export interface UserSummary {
  id: number
  tenantId: number
  email: string
  fullName: string
  emailVerified: boolean
  roles: Role[]
}

export interface AuthResponse {
  accessToken: string
  refreshToken: string
  expiresInSeconds: number
  user: UserSummary
}

export interface TenantInfo {
  id: number
  name: string
  status: string
  planCode: string
  trialEndsAt: string | null
}

export type CompanyStatus = 'ACTIVE' | 'ARCHIVED'

export interface Company {
  id: number
  name: string
  industry: string | null
  brandVoice: string | null
  website: string | null
  status: CompanyStatus
  onboardingStep: number
  createdAt: string
}

export interface CompanyInput {
  name: string
  industry?: string
  brandVoice?: string
  website?: string
}

// ---- Strange Loop (Phase 2) ----

export type IterationStatus = 'RUNNING' | 'COMPLETED' | 'FAILED'

export interface LoopIteration {
  id: number
  companyId: number
  iterationNo: number
  status: IterationStatus
  triggerType: string
  startedAt: string | null
  completedAt: string | null
}

export interface LoopStageRun {
  stageNo: number
  stageName: string
  status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED'
  progressPct: number
  dataJson: string | null
  startedAt: string | null
  completedAt: string | null
}

export interface LoopIterationDetail {
  iteration: LoopIteration
  insightsJson: string | null
  gapsJson: string | null
  stages: LoopStageRun[]
}

/** Real-time message pushed over STOMP (`/topic/tenant.{id}.loop`). */
export interface LoopUpdate {
  type:
    | 'ITERATION_STARTED'
    | 'STAGE_STARTED'
    | 'STAGE_COMPLETED'
    | 'ITERATION_COMPLETED'
    | 'ITERATION_FAILED'
  iterationId: number
  companyId: number
  iterationNo: number
  stageNo: number | null
  stageName: string | null
  stageStatus: string | null
  iterationStatus: IterationStatus
  progressPct: number
  message: string
  at: string
}
