package com.cmo2.tenancy.service;

import com.cmo2.shared.audit.AuditService;
import com.cmo2.shared.exceptions.ApiException;
import com.cmo2.tenancy.domain.Company;
import com.cmo2.tenancy.domain.CompanyStatus;
import com.cmo2.tenancy.dto.CompanyDtos.CompanyResponse;
import com.cmo2.tenancy.dto.CompanyDtos.CreateCompanyRequest;
import com.cmo2.tenancy.dto.CompanyDtos.UpdateCompanyRequest;
import com.cmo2.tenancy.repository.CompanyRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Company CRUD for the Multi-Company module. Every read/write is implicitly
 * tenant-scoped by the Hibernate filter, so there is no way to touch another
 * tenant's company even with a guessed id.
 *
 * <p>Authorization is enforced HERE (service layer) via {@code @PreAuthorize},
 * per the non-negotiable rule — the UI's role checks are convenience only.
 */
@Service
public class CompanyService {

    private final CompanyRepository companyRepository;
    private final AuditService auditService;

    public CompanyService(CompanyRepository companyRepository, AuditService auditService) {
        this.companyRepository = companyRepository;
        this.auditService = auditService;
    }

    @Transactional(readOnly = true)
    @PreAuthorize("hasAnyRole('OWNER','ADMIN','STRATEGIST','ANALYST','VIEWER')")
    public List<CompanyResponse> list() {
        return companyRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(CompanyService::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    @PreAuthorize("hasAnyRole('OWNER','ADMIN','STRATEGIST','ANALYST','VIEWER')")
    public CompanyResponse get(Long id) {
        return toResponse(findOwned(id));
    }

    @Transactional
    @PreAuthorize("hasAnyRole('OWNER','ADMIN')")
    public CompanyResponse create(CreateCompanyRequest req) {
        if (companyRepository.existsByName(req.name().trim())) {
            throw ApiException.conflict("A company named '" + req.name().trim() + "' already exists");
        }
        Company company = new Company();
        company.setName(req.name().trim());
        company.setIndustry(req.industry());
        company.setBrandVoice(req.brandVoice());
        company.setWebsite(req.website());
        company.setStatus(CompanyStatus.ACTIVE);
        company = companyRepository.save(company);

        auditService.record("COMPANY_CREATED", "Company", String.valueOf(company.getId()), company.getName());
        return toResponse(company);
    }

    @Transactional
    @PreAuthorize("hasAnyRole('OWNER','ADMIN')")
    public CompanyResponse update(Long id, UpdateCompanyRequest req) {
        Company company = findOwned(id);
        company.setName(req.name().trim());
        company.setIndustry(req.industry());
        company.setBrandVoice(req.brandVoice());
        company.setWebsite(req.website());
        company = companyRepository.save(company);

        auditService.record("COMPANY_UPDATED", "Company", String.valueOf(company.getId()), company.getName());
        return toResponse(company);
    }

    @Transactional
    @PreAuthorize("hasAnyRole('OWNER','ADMIN')")
    public void archive(Long id) {
        Company company = findOwned(id);
        company.setStatus(CompanyStatus.ARCHIVED);
        companyRepository.save(company);
        auditService.record("COMPANY_ARCHIVED", "Company", String.valueOf(company.getId()), company.getName());
    }

    private Company findOwned(Long id) {
        // Filter guarantees this only returns a company in the current tenant.
        return companyRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("Company not found"));
    }

    private static CompanyResponse toResponse(Company c) {
        return new CompanyResponse(
                c.getId(), c.getName(), c.getIndustry(), c.getBrandVoice(), c.getWebsite(),
                c.getStatus(), c.getOnboardingStep(), c.getCreatedAt());
    }
}
