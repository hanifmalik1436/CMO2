package com.cmo2.tenancy.repository;

import com.cmo2.tenancy.domain.Tenant;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TenantRepository extends JpaRepository<Tenant, Long> {
}
