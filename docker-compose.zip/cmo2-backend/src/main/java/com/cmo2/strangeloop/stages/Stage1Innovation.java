package com.cmo2.strangeloop.stages;

import com.cmo2.strangeloop.domain.StageName;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Stage 1 — Innovation. Generates a marketing strategy. In Phase 5 this is fed by
 * the AI Strategist Council; for now it emits a structured placeholder strategy.
 */
@Service
public class Stage1Innovation implements LoopStage {

    @Override
    public StageName name() {
        return StageName.INNOVATION;
    }

    @Override
    public Map<String, Object> run(StageContext context) {
        Map<String, Object> strategy = Map.of(
                "objective", "Grow qualified leads while holding CPL steady",
                "initiatives", List.of(
                        "Tighten audience targeting on paid search",
                        "Launch a 7-email nurture sequence",
                        "Refresh top landing page above the fold"),
                "channels", List.of("paid_search", "email", "landing_pages"),
                "source", "stub:innovation"
        );
        context.put("strategy", strategy);
        return strategy;
    }
}
