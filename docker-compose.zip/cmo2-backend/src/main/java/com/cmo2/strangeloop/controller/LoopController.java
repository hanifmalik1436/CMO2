package com.cmo2.strangeloop.controller;

import com.cmo2.strangeloop.dto.LoopDtos.IterationDetailResponse;
import com.cmo2.strangeloop.dto.LoopDtos.IterationResponse;
import com.cmo2.strangeloop.service.LoopService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
@Tag(name = "Strange Loop")
public class LoopController {

    private final LoopService loopService;

    public LoopController(LoopService loopService) {
        this.loopService = loopService;
    }

    @PostMapping("/companies/{companyId}/loop/cycles")
    @ResponseStatus(HttpStatus.ACCEPTED)
    @Operation(summary = "Run a Strange Loop cycle for a company (async; watch progress over WebSocket)")
    public IterationResponse runCycle(@PathVariable Long companyId) {
        return loopService.runCycle(companyId);
    }

    @GetMapping("/companies/{companyId}/loop/cycles")
    @Operation(summary = "List a company's loop iterations (newest first)")
    public List<IterationResponse> listCycles(@PathVariable Long companyId) {
        return loopService.listIterations(companyId);
    }

    @GetMapping("/loop/cycles/{iterationId}")
    @Operation(summary = "Get a loop iteration with its 5 stage runs + insights/gaps")
    public IterationDetailResponse getCycle(@PathVariable Long iterationId) {
        return loopService.getIteration(iterationId);
    }
}
