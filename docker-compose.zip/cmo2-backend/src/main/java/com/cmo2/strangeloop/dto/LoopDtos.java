package com.cmo2.strangeloop.dto;

import com.cmo2.strangeloop.domain.LoopIteration;
import com.cmo2.strangeloop.domain.LoopStageRun;

import java.time.Instant;
import java.util.List;

/** Response DTOs for the Strange Loop module. */
public final class LoopDtos {

    private LoopDtos() {}

    public record IterationResponse(
            Long id,
            Long companyId,
            int iterationNo,
            String status,
            String triggerType,
            Instant startedAt,
            Instant completedAt
    ) {
        public static IterationResponse of(LoopIteration it) {
            return new IterationResponse(it.getId(), it.getCompanyId(), it.getIterationNo(),
                    it.getStatus().name(), it.getTriggerType().name(), it.getStartedAt(), it.getCompletedAt());
        }
    }

    public record StageRunResponse(
            int stageNo,
            String stageName,
            String status,
            int progressPct,
            String dataJson,
            Instant startedAt,
            Instant completedAt
    ) {
        public static StageRunResponse of(LoopStageRun s) {
            return new StageRunResponse(s.getStageNo(), s.getStageName().name(), s.getStatus().name(),
                    s.getProgressPct(), s.getDataJson(), s.getStartedAt(), s.getCompletedAt());
        }
    }

    public record IterationDetailResponse(
            IterationResponse iteration,
            String insightsJson,
            String gapsJson,
            List<StageRunResponse> stages
    ) {}
}
