package com.cmo2.strangeloop.orchestrator;

import com.cmo2.shared.security.TenantContext;
import com.cmo2.strangeloop.domain.TriggerType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * Schedules the next cycle after one completes ("loop back"). In-process scheduler;
 * fires a SCHEDULED cycle for the same company after a configurable interval.
 */
@Component
public class LoopScheduler {

    private static final Logger log = LoggerFactory.getLogger(LoopScheduler.class);

    private final TaskScheduler taskScheduler;
    private final ObjectProvider<LoopOrchestrator> orchestratorProvider; // lazy → avoids ctor cycle

    @Value("${cmo2.loop.reschedule-seconds:86400}")
    private long rescheduleSeconds;

    public LoopScheduler(@Qualifier("loopTaskScheduler") TaskScheduler taskScheduler,
                         ObjectProvider<LoopOrchestrator> orchestratorProvider) {
        this.taskScheduler = taskScheduler;
        this.orchestratorProvider = orchestratorProvider;
    }

    public void scheduleNext(Long tenantId, Long companyId) {
        if (rescheduleSeconds <= 0) {
            log.debug("Auto-reschedule disabled (cmo2.loop.reschedule-seconds <= 0)");
            return;
        }
        Instant when = Instant.now().plus(rescheduleSeconds, ChronoUnit.SECONDS);
        taskScheduler.schedule(() -> runScheduled(tenantId, companyId), when);
        log.info("Scheduled next loop cycle for company {} at {}", companyId, when);
    }

    private void runScheduled(Long tenantId, Long companyId) {
        // No request thread here — bind the tenant explicitly so creation is scoped correctly.
        TenantContext.set(tenantId, null);
        try {
            orchestratorProvider.getObject().startCycle(companyId, TriggerType.SCHEDULED);
        } catch (Exception e) {
            log.error("Scheduled loop cycle for company {} failed to start", companyId, e);
        } finally {
            TenantContext.clear();
        }
    }
}
