package com.cmo2.strangeloop.orchestrator;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

/**
 * Threading for the Strange Loop. A small executor runs cycles off the request
 * thread (so "Run Cycle" returns immediately and the UI watches via WebSocket);
 * a scheduler fires the next cycle.
 *
 * <p>Phase 2 uses an in-process scheduler. Swapping to a Quartz JDBC job store
 * (cluster-safe, survives restarts) is a Phase 7 hardening step — the
 * {@link LoopResumeRunner} already covers single-node crash-resume of in-flight cycles.
 */
@Configuration
public class LoopConfig {

    @Bean(name = "loopTaskExecutor")
    public ThreadPoolTaskExecutor loopTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(8);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("loop-");
        executor.initialize();
        return executor;
    }

    @Bean(name = "loopTaskScheduler")
    public TaskScheduler loopTaskScheduler() {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(2);
        scheduler.setThreadNamePrefix("loop-sched-");
        scheduler.initialize();
        return scheduler;
    }
}
