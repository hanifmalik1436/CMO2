package com.cmo2.strangeloop.stages;

import java.util.HashMap;
import java.util.Map;

/**
 * Carries data between stages within one iteration. Stage 1 writes "strategy",
 * Stage 2 reads it and writes "insights", and so on — mirroring the orchestrator
 * pipeline in the architecture doc.
 */
public class StageContext {

    private final Long companyId;
    private final int iterationNo;
    private final Map<String, Object> shared = new HashMap<>();

    public StageContext(Long companyId, int iterationNo) {
        this.companyId = companyId;
        this.iterationNo = iterationNo;
    }

    public Long companyId() {
        return companyId;
    }

    public int iterationNo() {
        return iterationNo;
    }

    public void put(String key, Object value) {
        shared.put(key, value);
    }

    public Object get(String key) {
        return shared.get(key);
    }
}
