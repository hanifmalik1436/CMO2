package com.cmo2.strangeloop.stages;

import com.cmo2.strangeloop.domain.StageName;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Stage 2 — Learning. Pattern analysis over KPI snapshots. Until Phase 3 wires
 * real platform data into {@code kpi_snapshots}, this reports zero data points and
 * low confidence — honestly, rather than inventing numbers.
 */
@Service
public class Stage2Learning implements LoopStage {

    @Override
    public StageName name() {
        return StageName.LEARNING;
    }

    @Override
    public Map<String, Object> run(StageContext context) {
        Map<String, Object> insights = Map.of(
                "dataPoints", 0,
                "confidence", 0.0,
                "observations", List.of(
                        "No KPI snapshots available yet — connect a platform (Phase 3) to enable learning."),
                "patterns", List.of(),
                "source", "stub:learning"
        );
        context.put("insights", insights);
        return insights;
    }
}
