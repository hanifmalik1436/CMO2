package com.cmo2.strangeloop.stages;

import com.cmo2.strangeloop.domain.StageName;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Stage 3 — Documentation. Pushes insights/SOPs to Notion / Confluence / Linear.
 * Phase 6 implements the real API pushes; here it records intent only.
 */
@Service
public class Stage3Documentation implements LoopStage {

    @Override
    public StageName name() {
        return StageName.DOCUMENTATION;
    }

    @Override
    public Map<String, Object> run(StageContext context) {
        return Map.of(
                "documented", false,
                "targets", List.of("notion", "linear", "confluence"),
                "note", "Auto-documentation targets configured but not yet connected (Phase 6).",
                "source", "stub:documentation"
        );
    }
}
