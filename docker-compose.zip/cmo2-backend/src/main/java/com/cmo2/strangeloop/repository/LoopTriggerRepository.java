package com.cmo2.strangeloop.repository;

import com.cmo2.strangeloop.domain.LoopTrigger;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LoopTriggerRepository extends JpaRepository<LoopTrigger, Long> {

    List<LoopTrigger> findByCompanyIdAndActiveTrue(Long companyId);
}
