package com.cmo2.strangeloop.stages;

import com.cmo2.strangeloop.domain.StageName;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Stage 4 — Reporting. Identifies gaps between current performance and targets.
 * With no KPI data yet, every gap is reported as "unknown" rather than fabricated.
 */
@Service
public class Stage4Reporting implements LoopStage {

    @Override
    public StageName name() {
        return StageName.REPORTING;
    }

    @Override
    public Map<String, Object> run(StageContext context) {
        Map<String, Object> gaps = Map.of(
                "targetsEvaluated", List.of("CPL", "ROAS", "Leads", "ConversionRate"),
                "targetsMet", 0,
                "gaps", List.of(
                        Map.of("metric", "CPL", "status", "unknown", "reason", "no data"),
                        Map.of("metric", "ROAS", "status", "unknown", "reason", "no data")),
                "source", "stub:reporting"
        );
        context.put("gaps", gaps);
        return gaps;
    }
}
